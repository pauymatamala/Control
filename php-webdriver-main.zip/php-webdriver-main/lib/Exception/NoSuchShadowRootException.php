<?php

namespace Facebook\WebDriver\Exception;

/**
 * The element does not have a shadow root.
 */
class NoSuchShadowRootException extends WebDriverException
{
}
